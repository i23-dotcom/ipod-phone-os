package com.ipod.phoneos

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BrowserActivity : AppCompatActivity() {
    companion object { const val EXTRA_URL = "url" }
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 14, 18)
        window.navigationBarColor = Color.rgb(11, 14, 18)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 14, 18))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 8)
        }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { action() }
            minWidth = 48
        }
        bar.addView(button("‹") { if (web.canGoBack()) web.goBack() }, LinearLayout.LayoutParams(48, 52))
        bar.addView(button("›") { if (web.canGoForward()) web.goForward() }, LinearLayout.LayoutParams(48, 52))
        bar.addView(button("↻") { web.reload() }, LinearLayout.LayoutParams(48, 52))
        address = EditText(this).apply {
            hint = "Search or enter website"
            singleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setOnEditorActionListener { _, _, _ -> navigate(); true }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 52, 1f))
        bar.addView(button("×") { finish() }, LinearLayout.LayoutParams(48, 52))
        root.addView(bar)

        status = TextView(this).apply {
            text = "READY"
            setTextColor(Color.rgb(220, 230, 210))
            setPadding(10, 4, 10, 4)
            setBackgroundColor(Color.rgb(34, 50, 30))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 34))

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.setSupportMultipleWindows(true)
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                address.setText(url); status.text = "LOADING"
            }
            override fun onPageFinished(view: WebView, url: String) {
                address.setText(url); status.text = "LOADED"
            }
        }

        val initial = intent.getStringExtra(EXTRA_URL).orEmpty().ifBlank { "https://www.google.com/" }
        load(initial)
    }

    private fun normalize(value: String): String {
        val v = value.trim()
        if (v.isBlank()) return "https://www.google.com/"
        if (v.startsWith("http://") || v.startsWith("https://")) return v
        if (v.matches(Regex("[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/.*)?"))) return "https://$v"
        return "https://www.google.com/search?q=" + java.net.URLEncoder.encode(v, "UTF-8")
    }

    private fun load(value: String) { val url = normalize(value); address.setText(url); web.loadUrl(url) }
    private fun navigate() { load(address.text.toString()) }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
