# iPod Phone OS — GitHub-ready Android project

Native Android/Kotlin shell for the iPod Phone OS HTML interface.

## Build with GitHub Actions

Push this project to GitHub. The workflow in `.github/workflows/build-apk.yml` builds `app-debug.apk` and publishes it as a workflow artifact.

## Included

- Local iPod Phone OS HTML UI in `app/src/main/assets/index.html`
- Android WebView with JavaScript and DOM storage
- Native camera/microphone permission bridge
- Android file chooser for audio/video/M3U/APK inputs
- Native full-screen browser Activity (replaces the old iframe/proxy browser path when running as the APK)
- HTTP/HTTPS support for WebView content
- Android download handoff
- Virtual phone/app manager UI from the HTML source
- Unified Media Library search from the source UI

## Important platform behavior

An ordinary Android app cannot silently install or execute arbitrary APK binaries. APK installation is handed to Android's package installer/user confirmation. The HTML virtual phone can keep package records, while real installed apps are handled by Android.
